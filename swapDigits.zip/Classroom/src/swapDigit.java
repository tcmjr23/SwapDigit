
public class swapDigit {
	public static void main(String[] args) {
		System.out.println(swapDigitPairs(1234567));
		return;
	}
	public static int swapDigitPairs(int n) {
		int swap = 0;
		int temp1 = 0;
		int temp2 = 0;
		for(int i = 1;n>0;i*=100) {
			temp1 = n%10;
			n/=10;
			if(n==0) {
				if(i==0) {
				swap +=temp1*1;
				}else {
					System.out.println("test"+temp1);
					swap +=(temp1*i);
					temp1 = (temp1*((i*10)));
					System.out.println("after else"+temp1);
				}
			}
			else {
				temp2 = n%10;
				System.out.println("ladder" + temp1);
				temp1 = (temp1*(i*10));
				System.out.println("after temp1 =" + temp1);
				System.out.println("temp2: " + temp2);
				if(i>1) {
					temp2 *= i;
					System.out.println("math.pow result: " + temp2);
				}
				swap += temp1+temp2;
				n/=10;
				System.out.println(temp1 + " + " + temp2 + "   swap: " + swap);
			}
		}
		System.out.println("swap: " + swap);
		return swap;
	}
}
	
